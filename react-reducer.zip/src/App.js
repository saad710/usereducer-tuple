import logo from './logo.svg';
import './App.css';
import GetPost from './GetPost';
import TestReducer from './TestReducer';
import Test from './Test';


function App() {
  return (
    <div className="App">
        {/* <TestReducer/> */}
        <Test/>
    </div>
  );
}

export default App;
